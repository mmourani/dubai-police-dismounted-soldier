# BILL OF QUANTITIES (BOQ)
## Dubai Police SWAT Tactical Communication System
### Detailed Component List with Specifications
### Date: August 29, 2025

---

## SECTION 1: AUDIO COMMUNICATION SYSTEM

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 1.1 | INVISIO V60 II Control Unit | - Dimensions: 70×63×25mm<br>- Weight: 152g<br>- 4× PTT buttons<br>- 3× audio channels<br>- IP68 rated<br>- MIL-STD-810H | Each | 1 | 15,950 | 15,950 |
| 1.2 | INVISIO X7 In-Ear Headset | - Weight: 47g<br>- SNR: 39dB<br>- Frequency: 20Hz-20kHz<br>- Cable: 1.2m<br>- Connector: Proprietary | Each | 1 | 7,250 | 7,250 |
| **SUBTOTAL AUDIO** | | | | | | **23,200** |

---

## SECTION 2: END USER DEVICE SYSTEM

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 2.1 | Samsung Galaxy S23 Ultra | - Storage: 512GB<br>- RAM: 12GB<br>- Display: 6.8"<br>- 5G enabled<br>- Android 14<br>- Dimensions: 146.3×70.9×7.6mm | Each | 1 | 6,525 | 6,525 |
| 2.2 | Bunker MAAK Tactical Case | - Material: Polycarbonate<br>- Protection: MIL-STD-810H<br>- Mount: MAAKLOCK system<br>- Color: Tan/Coyote<br>- Weight: 180g | Each | 1 | 1,740 | 1,740 |
| **SUBTOTAL DEVICE** | | | | | | **8,265** |

---

## SECTION 3: POWER SYSTEM

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 3.1 | Primary Battery Pack | - Capacity: 21,000mAh<br>- Chemistry: LiFePO4<br>- Output: USB-C PD 65W<br>- Dimensions: 150×80×25mm<br>- Weight: 420g<br>- Temp: -20°C to 60°C | Each | 1 | 3,265 | 3,265 |
| 3.2 | Secondary Battery Pack | - Same specifications as 3.1<br>- Hot-swappable configuration | Each | 1 | 3,260 | 3,260 |
| 3.3 | Hot-Swap Controller | - Input: 2× USB-C<br>- Output: 3× USB-C<br>- Switching: <10ms<br>- Protection: OCP/OVP<br>- LED indicators | Each | 1 | 1,160 | 1,160 |
| 3.4 | Dual Charging Station | - Input: 100-240VAC<br>- Output: 2× 65W USB-C<br>- Charging time: 4 hours<br>- LED status display | Each | 1 | 870 | 870 |
| **SUBTOTAL POWER** | | | | | | **8,555** |

---

## SECTION 4: CABLE SYSTEM

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 4.1 | Tetra to INVISIO Cable | - Connector A: 26-pin Tetra<br>- Connector B: INVISIO proprietary<br>- Length: 60cm<br>- Shielding: EMI/RFI<br>- Jacket: TPU tactical | Each | 1 | 1,740 | 1,740 |
| 4.2 | Samsung to INVISIO Cable | - Connector A: USB-C<br>- Connector B: INVISIO data<br>- Length: 50cm<br>- Data rate: USB 3.0<br>- Power: Pass-through | Each | 1 | 1,160 | 1,160 |
| 4.3 | Power Cable - Primary | - Type: USB-C to USB-C<br>- Rating: 100W PD<br>- Length: 80cm<br>- AWG: 20<br>- Certification: USB-IF | Each | 1 | 435 | 435 |
| 4.4 | Power Cable - Secondary | - Type: USB-C to USB-C<br>- Rating: 65W PD<br>- Length: 40cm<br>- AWG: 22<br>- Certification: USB-IF | Each | 1 | 435 | 435 |
| 4.5 | Cable Management Kit | - Velcro straps: 10×<br>- Cable channels: 2m<br>- Clips: 20×<br>- Spiral wrap: 2m | Set | 1 | 580 | 580 |
| **SUBTOTAL CABLES** | | | | | | **4,350** |

---

## SECTION 5: MOUNTING & INTEGRATION HARDWARE

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 5.1 | Forearm Mount Platform | - Material: Kydex<br>- Straps: 3× adjustable<br>- Padding: EVA foam<br>- Quick-release: Yes<br>- Weight: 120g | Each | 1 | 725 | 725 |
| 5.2 | Radio Pouch | - Type: MOLLE compatible<br>- Material: 500D Cordura<br>- Closure: Velcro + snap<br>- Drainage: Yes<br>- Color: Tan | Each | 1 | 435 | 435 |
| 5.3 | Battery Pouch | - Type: MOLLE compatible<br>- Capacity: 2× batteries<br>- Material: 500D Cordura<br>- Ventilation: Mesh panel<br>- Color: Tan | Each | 1 | 435 | 435 |
| 5.4 | Integration Hardware Set | - MOLLE clips: 6×<br>- Carabiners: 4×<br>- Cable ties: 20×<br>- Mounting screws: Set<br>- Velcro patches: 8× | Set | 1 | 580 | 580 |
| **SUBTOTAL MOUNTING** | | | | | | **2,175** |

---

## SECTION 6: SERVICES & SUPPORT

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 6.1 | System Integration | - Assembly: 8 hours<br>- Configuration: 4 hours<br>- Programming: 2 hours<br>- Cable routing: 2 hours<br>- Total: 16 hours labor | Service | 1 | 2,900 | 2,900 |
| 6.2 | Environmental Testing | - Temperature: -20°C to 50°C<br>- Humidity: 95% RH<br>- Vibration: MIL-STD<br>- Drop: 1.5m<br>- Duration: 8 hours | Service | 1 | 2,175 | 2,175 |
| 6.3 | Quality Certification | - Documentation: Complete<br>- Test reports: All items<br>- Certificates: CE, FCC<br>- Warranty cards: Included<br>- Serial tracking | Service | 1 | 1,450 | 1,450 |
| **SUBTOTAL SERVICES** | | | | | | **6,525** |

---

## SECTION 7: PACKAGING & DOCUMENTATION

| Item # | Description | Specification | Unit | Qty/Kit | Unit Price (AED) | Total (AED) |
|--------|-------------|---------------|------|---------|------------------|-------------|
| 7.1 | Tactical Storage Case | - Type: Pelican equivalent<br>- Size: 50×40×20cm<br>- Rating: IP67<br>- Foam: Custom cut<br>- Wheels: No | Each | 1 | 290 | 290 |
| 7.2 | User Manual | - Language: English/Arabic<br>- Pages: 120<br>- Format: A5 spiral<br>- Content: Full system<br>- Quick guide: Laminated | Each | 1 | 145 | 145 |
| 7.3 | Quick Reference Cards | - Size: Credit card<br>- Material: PVC<br>- Content: PTT map<br>- Quantity: 2 cards<br>- Attachment: Lanyard | Set | 1 | 90 | 90 |
| 7.4 | Digital Documentation | - Format: PDF + Video<br>- Content: Training videos<br>- Access: QR code<br>- Updates: 12 months | Package | 1 | 90 | 90 |
| **SUBTOTAL PACKAGING** | | | | | | **615** |

---

## GRAND TOTAL PER KIT

| Section | Description | Total (AED) |
|---------|-------------|-------------|
| Section 1 | Audio Communication System | 23,200 |
| Section 2 | End User Device System | 8,265 |
| Section 3 | Power System | 8,555 |
| Section 4 | Cable System | 4,350 |
| Section 5 | Mounting & Integration | 2,175 |
| Section 6 | Services & Support | 6,525 |
| Section 7 | Packaging & Documentation | 615 |
| **GRAND TOTAL** | **Complete Kit Price** | **53,685** |

---

## QUANTITY PRICING MATRIX

| Description | 6 Kits | 8 Kits | 10 Kits |
|-------------|--------|--------|---------|
| **Unit Price** | 53,685 | 53,685 | 53,685 |
| **Total Equipment** | 322,110 | 429,480 | 536,850 |
| **Spare Parts (20%)** | 64,422 | 85,896 | 107,370 |
| **Training Package** | 43,500 | 43,500 | 43,500 |
| **Annual Support** | 72,500 | 72,500 | 72,500 |
| **Complete Package** | **502,532** | **631,376** | **760,220** |

---

## OPTIONAL ITEMS (NOT INCLUDED)

| Item | Description | Unit Price (AED) |
|------|-------------|------------------|
| Tactical Vest | If not provided by customer | 2,900 |
| Helmet Mount Kit | For X7 headset alternative mounting | 870 |
| Extended Battery | 30,000mAh upgrade | 2,175 |
| Wireless PTT | INVISIO V60 wireless button | 3,480 |
| Body Camera | Integration ready | 5,800 |
| Extra Headset | Spare INVISIO X7 | 7,250 |
| Vehicle Kit | 12V charging system | 1,450 |

---

## NOTES

1. **Prices:** Valid for 30 days from date
2. **Warranty:** 12 months on main components, 90 days on cables
3. **Delivery:** Air freight
4. **Payment:** As per government procurement terms
5. **Tetra Radio:** To be provided by Dubai Police
6. **VAT:** Not included (add 5% if applicable)
7. **Minimum Order:** 6 units
8. **Origin:** Multi-country (USA, Sweden, Korea, UAE)

---

## COMPLIANCE & STANDARDS

- **Environmental:** MIL-STD-810H
- **EMC:** MIL-STD-461G
- **Protection:** IP68 (main components)
- **Safety:** CE, FCC certified
- **Battery:** UN38.3 transportation certified
- **Audio:** EN 352-2:2020 hearing protection

---

**Document Reference:** DP-SWAT-BOQ-2025-001  
**Prepared for:** Dubai Police Special Operations  
**Valid Until:** February 28, 2025

---

**END OF DOCUMENT**