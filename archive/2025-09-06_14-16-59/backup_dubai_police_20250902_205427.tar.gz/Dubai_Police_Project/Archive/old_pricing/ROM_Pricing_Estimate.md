# ROM PRICING ESTIMATE
**Version: v2.0**
## Dubai Police SWAT Tactical Communication System
### Rough Order of Magnitude - CONFIDENTIAL
### Date: January 29, 2025
### Pricing Structure: 45% Margin on Individual Components

---

## EXECUTIVE SUMMARY

| Configuration | Unit Price (AED) | 6 Kits Total | 8 Kits Total | 10 Kits Total | Lead Time |
|---------------|-----------------|--------------|--------------|---------------|----------|
| **INVISIO TACTICAL SYSTEM** | 56,295 | 337,770 | 450,360 | 562,950 | 6-8 weeks |
| **With Volume Discount** | - | 337,770 | 439,100 | 535,000 | 6-8 weeks |

*Prices include 45% margin on each component - standard industry markup for tactical systems*
*Customer provides Tetra radio - not included in pricing*

---

## DETAILED PRICING BREAKDOWN

### Component Cost Structure (Per Unit)
**Pricing Method:** Each component cost + 45% margin = selling price

| Category | Component | Raw Cost (AED) | 45% Margin | Selling Price (AED) | Notes |
|----------|-----------|----------------|------------|-------------------|-------|
| **Audio System** |
| | INVISIO V60 II Control Unit | 11,000 | 4,950 | **15,950** | Chest-mounted, 4 PTT |
| | INVISIO X7 In-Ear Headset | 5,000 | 2,250 | **7,250** | 39dB SNR, MIL-STD |
| **End User Device** |
| | Samsung Galaxy S25 Ultra | 4,500 | 2,025 | **6,525** | 512GB, 5G |
| | Bunker MAAK Tactical Case | 1,200 | 540 | **1,740** | Forearm mount |
| | ATAK Software License | 1,800 | 810 | **2,610** | Government version |
| **Power System** |
| | Dual 21,000mAh Battery Pack | 4,500 | 2,025 | **6,525** | Hot-swappable |
| | Hot-Swap Controller Circuit | 800 | 360 | **1,160** | Custom design |
| | Charging Station | 600 | 270 | **870** | Dual-bay |
| **Cables & Connectors** |
| | Tetra to INVISIO Cable | 1,200 | 540 | **1,740** | 26-pin custom |
| | Samsung to INVISIO Cable | 800 | 360 | **1,160** | USB-C to proprietary |
| | Power Distribution Cables (2×) | 600 | 270 | **870** | USB-C PD |
| | Cable Management System | 400 | 180 | **580** | Velcro/channels |
| **Mounting & Integration** |
| | Forearm Mount Platform | 500 | 225 | **725** | 3-strap system |
| | MOLLE Pouches (2×) | 600 | 270 | **870** | Radio & battery |
| | Vest Integration Hardware | 400 | 180 | **580** | Clips, straps |
| **Testing & Quality** |
| | System Integration Labor | 2,000 | 900 | **2,900** | Per unit |
| | Environmental Testing | 1,500 | 675 | **2,175** | 50°C validation |
| | Quality Certification | 1,000 | 450 | **1,450** | Documentation |
| **Documentation** |
| | User Manual (share of cost) | 300 | 135 | **435** | Per unit allocation |
| | Training Materials | 200 | 90 | **290** | Digital + print |
| **Packaging & Logistics** |
| | Tactical Case | 800 | 360 | **1,160** | Pelican equivalent |
| | Shipping Allocation | 500 | 225 | **725** | Per unit |

### TOTAL PRICING SUMMARY

| | Raw Cost | 45% Margin | **Selling Price** |
|---|----------|------------|------------------|
| **Components Total** | 35,100 | 15,795 | **50,895** |
| **Contingency (10%)** | 3,510 | 1,890 | **5,400** |
| **TOTAL PER KIT** | **38,610** | **17,685** | **56,295** |

### Volume Pricing Structure

| Quantity | Unit Price (AED) | Total (AED) | Discount | Effective Margin |
|----------|-----------------|-------------|----------|------------------|
| 1-5 units | 56,295 | - | 0% | 45% |
| 6-7 units | 56,295 | 337,770 (6) | 0% | 45% |
| 8-9 units | 54,888 | 439,100 (8) | 2.5% | 42% |
| 10+ units | 53,500 | 535,000 (10) | 5% | 38.5% |

---

## COST JUSTIFICATION & ANALYSIS

### Why 45% Margin is Industry Standard:

1. **Risk Mitigation (15%)**
   - Component availability risks
   - Technology integration challenges
   - Desert environment performance uncertainties
   - Samsung S25 pre-release risks

2. **Support & Warranty (15%)**
   - 12-month warranty coverage
   - Technical support infrastructure
   - Spare parts inventory
   - Field service capabilities

3. **Business Operations (15%)**
   - Project management
   - Quality assurance
   - Documentation
   - Profit margin

### Component Cost Breakdown:

| Component | How Cost Was Calculated |
|-----------|------------------------|
| INVISIO V60 II | Industry quote + UAE import (5%) |
| INVISIO X7 | Direct from INVISIO Abu Dhabi |
| Samsung S25 | MDS Mobile UAE pricing |
| Power System | LiFePO4 cells + controller design |
| Cables | MIL-SPEC fabrication quotes |
| Integration | 16 hours @ AED 125/hour |

---

## ADDITIONAL COSTS (OPTIONAL)

### Training & Support Package

| Service | Duration | Cost (AED) | 45% Margin | Total (AED) |
|---------|----------|------------|------------|-------------|
| Initial Training | 5 days | 30,000 | 13,500 | **43,500** |
| Advanced Training | 3 days | 20,000 | 9,000 | **29,000** |
| Annual Support | 12 months | 50,000 | 22,500 | **72,500** |
| Documentation | One-time | 15,000 | 6,750 | **21,750** |

### Spare Parts Package (20% of Equipment)

| Quantity | Base Cost | 45% Margin | Total (AED) | Components |
|----------|-----------|------------|-------------|------------|
| 6 Kits | 46,200 | 20,790 | **66,990** | 1 spare of each critical item |
| 8 Kits | 61,600 | 27,720 | **89,320** | 1.5 spares of each |
| 10 Kits | 77,000 | 34,650 | **111,650** | 2 spares of each |

### Logistics & Shipping

| Service | Cost (AED) | 45% Margin | Total (AED) | Timeline |
|---------|------------|------------|-------------|----------|
| Air Freight (Express) | 15,000 | 6,750 | **21,750** | 3-5 days |
| Sea Freight (Economy) | 8,000 | 3,600 | **11,600** | 4-6 weeks |
| Customs & Duties | - | - | 5% of CIF | At import |
| Insurance | - | - | 2% of value | Optional |

---

## TOTAL PROJECT COST COMPARISON

### 6 KITS DEPLOYMENT

| Item | Cost (AED) | Notes |
|------|------------|-------|
| Equipment (6 × 56,295) | **337,770** | No volume discount |
| Initial Training | **43,500** | 5 days on-site |
| Annual Support | **72,500** | 12 months |
| Spare Parts (20%) | **66,990** | Critical components |
| Air Freight | **21,750** | Express delivery |
| **PROJECT TOTAL** | **542,510** | ~AED 90,418 per operator |

### 8 KITS DEPLOYMENT

| Item | Cost (AED) | Notes |
|------|------------|-------|
| Equipment (8 × 54,888) | **439,100** | 2.5% volume discount |
| Initial Training | **43,500** | 5 days on-site |
| Annual Support | **72,500** | 12 months |
| Spare Parts (20%) | **89,320** | Critical components |
| Air Freight | **21,750** | Express delivery |
| **PROJECT TOTAL** | **666,170** | ~AED 83,271 per operator |

### 10 KITS DEPLOYMENT

| Item | Cost (AED) | Notes |
|------|------------|-------|
| Equipment (10 × 53,500) | **535,000** | 5% volume discount |
| Initial Training | **43,500** | 5 days on-site |
| Annual Support | **72,500** | 12 months |
| Spare Parts (20%) | **111,650** | Critical components |
| Air Freight | **21,750** | Express delivery |
| **PROJECT TOTAL** | **784,400** | ~AED 78,440 per operator |

---

## PAYMENT TERMS (STANDARD)

### 10 Kits Example (AED 535,000 equipment only)

| Milestone | Percentage | Amount (AED) | Timeline |
|-----------|------------|--------------|----------|
| Contract Signing | 30% | 160,500 | Day 0 |
| Component Procurement | 30% | 160,500 | Week 1 |
| Integration Complete | 30% | 160,500 | Week 4 |
| Final Acceptance | 10% | 53,500 | Week 6 |

---

## FINANCING OPTIONS

### Government Procurement Options
1. **Direct Purchase** - Full payment per milestones
2. **Annual Budget Split** - 50% this fiscal, 50% next
3. **Phased Deployment**
   - Phase 1: 3 units pilot (AED 160,000)
   - Phase 2: 4 units expansion (AED 220,000)
   - Phase 3: 3 units completion (AED 155,000)

---

## COST OPTIMIZATION STRATEGIES

### Potential Savings Opportunities

1. **Government Discounts**
   - Military/LE pricing: 10-15% reduction possible
   - GSA schedule rates if applicable
   - Direct government sales agreements

2. **Bundle Discounts**
   - Package deal with training: 5-8% savings
   - Multi-year support contracts: 10% reduction
   - Spare parts included: 5% savings

3. **Alternative Components**
   - Use single audio system (save $2,500/unit)
   - Standard antenna vs. custom (save $400/unit)
   - Basic vest option (save $400/unit)

4. **Regional Assembly**
   - Local integration partner: 15% labor savings
   - Regional spare parts depot: Reduced logistics
   - Local training resources: 30% training cost reduction

---

## COMPETITIVE ANALYSIS

| Competitor | Estimated Price | Strengths | Weaknesses |
|------------|-----------------|-----------|------------|
| L3Harris System | $48,000 - $55,000 | Established | Heavy, complex |
| Thales Solution | $42,000 - $50,000 | Integrated | Limited flexibility |
| Elbit Systems | $45,000 - $52,000 | Proven | Older technology |
| **Our Solution** | **$38,000 - $52,000** | **Latest tech, flexible** | **New integration** |

---

## EXECUTIVE RECOMMENDATIONS

### Best Value Proposition
**For Immediate Need:** DOCK-LITE Configuration
- 15% lower cost
- Immediate availability
- Proven components
- Easier maintenance

**For Future-Proof Solution:** NEXUS Configuration
- Superior integration
- Latest technology
- Lower total cost of ownership
- Better operational efficiency

### Recommended Approach
1. **Hybrid Deployment**
   - Order 3 DOCK-LITE units immediately for training
   - Place order for 7-10 NEXUS units for main deployment
   - Total investment: ~$500,000 for 10-13 total units

2. **Risk Mitigation**
   - Include 30-day acceptance period
   - Performance guarantees
   - Local support requirements
   - Technology refresh options

---

## NOTES & DISCLAIMERS

1. **Pricing Validity:** 30 days from date of estimate
2. **Currency:** All prices in USD, subject to exchange rate
3. **Assumptions:** 
   - Standard configurations
   - No special customization
   - Commercial off-the-shelf components
4. **Exclusions:**
   - VAT/Taxes (add 5% for UAE)
   - Special certifications
   - Custom software development
5. **Dependencies:**
   - Samsung S25 actual availability
   - NEXUS production schedule
   - Export license approvals

---

## NEXT STEPS FOR PRICING FINALIZATION

1. **Obtain formal quotes from:**
   - Silvus Technologies (NEXUS and SL5200)
   - INVISIO (V60 II systems)
   - Kagwerks (DOCK-Lite compatibility)
   - Silynx Communications
   - Glenair (cables)

2. **Confirm with Dubai Police:**
   - Exact quantity required
   - Delivery timeline
   - Payment terms preference
   - Support requirements

3. **Finalize:**
   - Volume discounts
   - Government pricing
   - Warranty terms
   - Training scope

---

*This ROM estimate is for budgetary planning purposes only*
*Final pricing subject to vendor quotations and negotiation*
*All prices exclusive of applicable taxes and duties*

**Document Classification: CONFIDENTIAL - NOT FOR DISTRIBUTION**