# Archive Plan — clean_snapshot

**Version:** v1.0
**Timestamp:** 2025-09-01T06:55:37.430Z
**Source Directory:** .
**Archive Location:** archive/clean_snapshot
**Mode:** APPLIED

## Statistics
- **Files to archive:** 0
- **Skipped:** 0
- **Duplicates found:** 0
- **Total size:** 0.00 MB

## By Category

## By Supplier
- (no suppliers identified)

## Configuration
- Copy mode: MOVE (destructive)
- Include hidden: false
- Max file size: 500 MB
- Hash files: true
- Dedupe: true
- Skip extensions: exe, dll, bin, iso, dmg, pkg

## Outputs
- `proposed-moves.csv` - Complete file manifest
- `inventory.jsonl` - Machine-readable index

✅ Files have been moved to archive.

## Retention
- Total archives before prune: 4
- Deleted: 0
- Kept: 4
